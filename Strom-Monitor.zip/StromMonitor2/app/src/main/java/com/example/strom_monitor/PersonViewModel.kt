package com.example.strom_monitor

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

// Wichtige Imports, die zuvor gefehlt haben könnten
import com.example.strom_monitor.AppDatabase
import com.example.strom_monitor.Person
import com.example.strom_monitor.PersonDao

class PersonViewModel(application: Application) : AndroidViewModel(application) {

    private val personDao: PersonDao
    val allePersonen: LiveData<List<Person>>

    init {
        val database = AppDatabase.getDatabase(application)
        personDao = database.personDao()
        allePersonen = personDao.getAllPersonen()
    }

    fun updatePerson(person: Person) {
        viewModelScope.launch(Dispatchers.IO) {
            personDao.update(person)
        }
    }
}