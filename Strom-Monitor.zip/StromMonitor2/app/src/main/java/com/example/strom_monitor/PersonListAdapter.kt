package com.example.strom_monitor

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import java.text.NumberFormat
import java.util.Locale

// Wichtige Imports, die zuvor gefehlt haben könnten
import com.example.strom_monitor.R
import com.example.strom_monitor.Person

class PersonListAdapter(
    private val onUpdate: (Person) -> Unit
) : RecyclerView.Adapter<PersonListAdapter.PersonViewHolder>() {

    private var personen = emptyList<Person>()

    companion object {
        const val PREIS_PRO_KWH = 0.35
        const val GRUNDGEBUEHR_MONATLICH = 10.00
    }

    class PersonViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nameTextView: TextView = itemView.findViewById(R.id.textViewName)
        val kwhTextView: TextView = itemView.findViewById(R.id.textViewKwh)
        val kostenTextView: TextView = itemView.findViewById(R.id.textViewKosten)
        val gesamtkostenTextView: TextView = itemView.findViewById(R.id.textViewGesamtkosten)
        val addKwhEditText: EditText = itemView.findViewById(R.id.editTextAddKwh)
        val addKwhButton: Button = itemView.findViewById(R.id.buttonAddKwh)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PersonViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.list_item_person, parent, false)
        return PersonViewHolder(itemView)
    }

    override fun getItemCount() = personen.size

    override fun onBindViewHolder(holder: PersonViewHolder, position: Int) {
        val currentPerson = personen[position]
        val context = holder.itemView.context

        val currencyFormat = NumberFormat.getCurrencyInstance(Locale.GERMANY)
        val numberFormat = NumberFormat.getNumberInstance(Locale.GERMANY)
        numberFormat.maximumFractionDigits = 2

        val kostenVerbrauch = currentPerson.verbrauchteKwh * PREIS_PRO_KWH
        val gesamtkosten = kostenVerbrauch + GRUNDGEBUEHR_MONATLICH

        holder.nameTextView.text = currentPerson.name
        holder.kwhTextView.text = "Verbrauch: ${numberFormat.format(currentPerson.verbrauchteKwh)} kWh"
        holder.kostenTextView.text = "Kosten Verbrauch: ${currencyFormat.format(kostenVerbrauch)}"
        holder.gesamtkostenTextView.text = "Gesamtkosten: ${currencyFormat.format(gesamtkosten)}"

        holder.addKwhButton.setOnClickListener {
            val kwhToAddText = holder.addKwhEditText.text.toString()
            if (kwhToAddText.isNotEmpty()) {
                try {
                    val kwhToAdd = kwhToAddText.toDouble()
                    currentPerson.verbrauchteKwh += kwhToAdd
                    onUpdate(currentPerson)
                    holder.addKwhEditText.text.clear()
                } catch (e: NumberFormatException) {
                    Toast.makeText(context, "Bitte eine gültige Zahl eingeben", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(context, "Bitte einen Wert eingeben", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun setData(neuePersonen: List<Person>) {
        this.personen = neuePersonen
        notifyDataSetChanged()
    }
}