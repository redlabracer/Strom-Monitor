package com.example.strom_monitor

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

// Wichtige Imports, die zuvor gefehlt haben könnten
import com.example.strom_monitor.Person
import com.example.strom_monitor.PersonListAdapter
import com.example.strom_monitor.PersonViewModel
import com.example.strom_monitor.R

class MainActivity : AppCompatActivity() {

    private lateinit var personViewModel: PersonViewModel
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: PersonListAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        personViewModel = ViewModelProvider(this).get(PersonViewModel::class.java)

        recyclerView = findViewById(R.id.recyclerView)
        adapter = PersonListAdapter { person ->
            personViewModel.updatePerson(person)
        }
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        personViewModel.allePersonen.observe(this) { personen ->
            personen?.let { adapter.setData(it) }
        }
    }
}